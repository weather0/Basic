set echo on
conn / as sysdba
archive log list
shutdown immediate
startup mount
ALTER DATABASE ARCHIVELOG
/
ALTER DATABASE OPEN
/
archive log list
set echo off
