select tablespace_name, file_name, bytes/1024/1024 as file_size
from dba_data_files
/
