set echo on
conn / as sysdba
DROP TABLESPACE mydata INCLUDING CONTENTS AND DATAFILES
/
set echo off
