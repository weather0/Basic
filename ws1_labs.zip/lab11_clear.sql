set echo on
conn / as sysdba
select group#, sequence#, members, status  from v$log
/
col member for a50
select group#, member, status from v$logfile
/
ALTER DATABASE DROP LOGFILE group 4
/
!rm /u01/app/oracle/oradata/orcl/redo04*
ALTER DATABASE DROP LOGFILE MEMBER '/u01/app/oracle/oradata/orcl/redo01a.log'
/
ALTER DATABASE DROP LOGFILE MEMBER '/u01/app/oracle/oradata/orcl/redo02a.log'
/
ALTER DATABASE DROP LOGFILE MEMBER '/u01/app/oracle/oradata/orcl/redo03a.log'
/
select group#, sequence#, members, status  from v$log
/
col member for a50
select group#, member, status from v$logfile
/
ALTER SYSTEM SET control_files = '/u01/app/oracle/oradata/orcl/control01.ctl' ,'/u01/app/oracle/flash_recovery_area/orcl/control02.ctl' SCOPE=SPFILE;
shutdown immediate
!rm  /u01/app/oracle/oradata/orcl/control03.ctl
conn / as sysdba
startup
select name from v$controlfile; 
!ls $ORACLE_BASE/oradata/orcl
set echo off
