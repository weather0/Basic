select avg(salary) from bigemp
/
