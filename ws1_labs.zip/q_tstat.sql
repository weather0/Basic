SELECT table_name, num_rows, blocks, empty_blocks, last_analyzed
FROM user_tables
/
