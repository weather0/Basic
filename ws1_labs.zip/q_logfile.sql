col member for a50
set linesize 120
SELECT group#, member, status
FROM v$logfile
/
