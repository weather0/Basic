set echo on
conn / as sysdba
archive log list
DECLARE
n NUMBER;
BEGIN
FOR n IN 1..&logswitch_count
LOOP
EXECUTE IMMEDIATE 'ALTER SYSTEM SWITCH LOGFILE';
END LOOP;
END;
/
ALTER SYSTEM CHECKPOINT
/
archive log list
set echo off