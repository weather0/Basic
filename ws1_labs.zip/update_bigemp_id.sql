set echo on
conn hr/hr
SELECT min(employee_id), max(employee_id)
FROM bigemp
/
UPDATE bigemp
SET employee_id = rownum
/
COMMIT
/
SELECT min(employee_id), max(employee_id)
FROM bigemp
/
set echo off