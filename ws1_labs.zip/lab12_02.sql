conn / as sysdba
SQL> alter database backup controlfile 
      To ‘/home/oracle/backup/control.bk’
/

