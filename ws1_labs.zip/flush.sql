alter system flush buffer_cache
/
