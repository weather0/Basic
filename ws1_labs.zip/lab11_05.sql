set echo on
conn / as sysdba
show parameter db_recovery
!ls  $ORACLE_BASE/flash_recovery_area 
UPDATE hr.bigemp
SET salary = salary*1.05;
COMMIT;
alter system switch logfile
/
alter system switch logfile
/
alter system switch logfile
/
alter system switch logfile
/
alter system switch logfile
/
alter system checkpoint
/
!ls $ORACLE_BASE/flash_recovery_area
!ls $ORACLE_BASE/flash_recovery_area/ORCL
!ls $ORACLE_BASE/flash_recovery_area/ORCL/archivelog
set echo off
