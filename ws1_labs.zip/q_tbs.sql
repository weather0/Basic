select tablespace_name, contents, status FROM dba_tablespaces
/
