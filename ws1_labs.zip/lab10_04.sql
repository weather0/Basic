set echo on
conn hr/hr
ALTER TABLE bigemp MOVE
/
set autotrace traceonly
SELECT * FROM bigemp
WHERE employee_id =32
/
set autotrace off
SELECT index_name, status FROM user_indexes
WHERE table_name = 'BIGEMP'
/
ALTER INDEX bigemp_empid_ix REBUILD
/
SELECT index_name, status FROM user_indexes
WHERE table_name = 'BIGEMP'
/
set autotrace traceonly
SELECT * FROM bigemp
WHERE employee_id =1854
/
set autotrace off
set echo off
