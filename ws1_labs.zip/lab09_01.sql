set echo on
conn hr/hr
SELECT table_name, num_rows, blocks, empty_blocks, last_analyzed
FROM user_tables
/
analyze table employees compute statistics
/
SELECT table_name, num_rows, blocks, empty_blocks, last_analyzed
FROM user_tables
/
analyze table employees delete statistics
/
SELECT table_name, num_rows, blocks, empty_blocks, last_analyzed
FROM user_tables
/
exec dbms_stats.gather_schema_stats('HR');
SELECT table_name, num_rows, blocks, empty_blocks, last_analyzed
FROM user_tables
/
exec dbms_stats.delete_schema_stats('HR');
SELECT table_name, num_rows, blocks, empty_blocks, last_analyzed
FROM user_tables
/
set echo off
