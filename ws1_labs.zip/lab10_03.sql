set echo on
conn / as sysdba
@?/sqlplus/admin/plustrce.sql
GRANT plustrace TO hr
/
conn hr/hr
DROP INDEX bigemp_empid_ix
/
SELECT index_name FROM user_indexes
WHERE table_name = 'BIGEMP'
/

set autotrace traceonly
SELECT * FROM bigemp
WHERE employee_id =123
/
set autotrace off
CREATE INDEX bigemp_empid_ix ON bigemp(employee_id)
/
SELECT index_name FROM user_indexes
WHERE table_name = 'BIGEMP'
/ 
set autotrace traceonly
SELECT * FROM bigemp
WHERE employee_id =234
/
set autotrace off
set echo off
