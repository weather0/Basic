set echo on
conn /as sysdba
select group#, sequence#, members, status, bytes/1024/1024 from v$log
/
col member for a50
select group#, member, status from v$logfile
/
alter database add logfile member '/u01/app/oracle/oradata/orcl/redo01a.log'  to group 1,
'/u01/app/oracle/oradata/orcl/redo02a.log' to group 2, '/u01/app/oracle/oradata/orcl/redo03a.log' to group 3 
/
ALTER DATABASE ADD LOGFILE GROUP 4 ( '/u01/app/oracle/oradata/orcl/redo04.log',  '/u01/app/oracle/oradata/orcl/redo04a.log') SIZE 50M
/
!ls $ORACLE_BASE/oradata/orcl
set echo off
