set echo on
conn / as sysdba
CREATE TABLESPACE mydata
DATAFILE '/u01/app/oracle/oradata/orcl/mydata.dbf' size 10m
/
conn hr/hr
CREATE TABLE emp_list
TABLESPACE mydata
AS
SELECT * FROM  employees
/
ALTER TABLE emp_list MODIFY (employee_id NUMBER)
/
DECLARE
         n NUMBER;
        BEGIN
        FOR n IN 1..13
        LOOP
        INSERT INTO emp_list SELECT * FROM emp_list;
        END LOOP;
        COMMIT;
        END; 
        /
set echo off
