set echo on
conn / as sysdba
show parameter pool_size
show parameter db_cache
show parameter target
select sum(value)/1024/1024 from v$sga
/
select pool, sum(bytes)/1024/1024 AS total_pool_size from v$sgastat
Where pool is not null
group by pool
/
select  current_size from v$buffer_pool
/
col component format a30
SELECT component, current_size/1024/1024
FROM v$sga_dynamic_components
/
set echo off
