conn / as sysdba
alter database backup controlfile to trace
/
select s.username, p.spid from v$session s JOIN v$process p
ON (s.paddr = p.addr)
and s.username = 'SYS'
/
