set echo on
conn / as sysdba
select group#, sequence#, members, status, bytes/1024/1024 as file_size,
        to_char(first_time, 'yy/mm/dd hh24:mi:ss') AS first_time
from v$log
/
col member for a50
select group#, member, status from v$logfile
/
alter system switch logfile
/
alter system switch logfile
/
alter system switch logfile
/
alter system switch logfile
/
alter system checkpoint
/
select group#, sequence#, members, status, bytes/1024/1024 as file_size,
        to_char(first_time, 'yy/mm/dd hh24:mi:ss') AS first_time
from v$log
/
col member for a50
select group#, member, status from v$logfile
/
set echo off
