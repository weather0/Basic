CREATE TABLE x_emp
      AS SELECT employee_id id, last_name name, job_id job, salary
     FROM employees
/
