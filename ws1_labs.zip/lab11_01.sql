set echo on
conn /as sysdba
CREATE PFILE FROM SPFILE
/
select name from v$controlfile
/
ALTER SYSTEM SET control_files = '/u01/app/oracle/oradata/orcl/control01.ctl' ,'/u01/app/oracle/flash_recovery_area/orcl/control02.ctl' ,    
'/u01/app/oracle/oradata/orcl/control03.ctl' SCOPE=SPFILE
/
shutdown immediate
! cp /u01/app/oracle/oradata/orcl/control01.ctl /u01/app/oracle/oradata/orcl/control03.ctl
conn / as sysdba
startup
select name from v$controlfile
/
set echo off
