set echo on
conn / as sysdba
show parameter target
ALTER SYSTEM SET memory_target = 0 scope=memory
/
show parameter target
startup force
show parameter target
set echo off
