set echo on
conn / as sysdba
archive log list
UPDATE hr.bigemp
SET salary = salary*1.1
/
COMMIT
/
archive log list
set echo off