set echo on
conn / as sysdba
ALTER DATABASE DATAFILE  '/u01/app/oracle/oradata/orcl/mydata.dbf' RESIZE 100m
/
conn hr/hr
TRUNCATE TABLE emp_list 
/
INSERT INTO emp_list
SELECT * FROM  employees
/
DECLARE
         n NUMBER;
        BEGIN
        FOR n IN 1..13
        LOOP
        INSERT INTO emp_list SELECT * FROM emp_list;
        END LOOP;
        COMMIT;
        END; 
        /
SELECT COUNT(*) FROM emp_list
/
set echo off
