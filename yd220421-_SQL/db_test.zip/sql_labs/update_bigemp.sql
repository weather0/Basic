SELECT MIN(employee_id), MAX(employee_id), COUNT(*) FROM bigemp
/
UPDATE bigemp
SET employee_id = rownum
/
COMMIT
/
SELECT MIN(employee_id), MAX(employee_id), COUNT(*) FROM bigemp
/