conn / as sysdba
alter database add supplemental log data
/
alter database add supplemental log data (primary key) columns
/
grant execute on dbms_flashback to hr
/
grant select any transaction to hr
/