DROP USER hr CASCADE;
create user hr identified by hr
default tablespace users;
grant connect, resource to hr;
grant create view, create synonym to hr;