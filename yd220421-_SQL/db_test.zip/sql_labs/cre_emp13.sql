drop table emp13 purge
/
create table emp13
as
select employee_id, last_name,job_id, salary, commission_pct, department_id
from employees
where department_id IN (10, 80)
/
update emp13
set department_id=200
/
update emp13
set commission_pct=0.4
/
commit
/
